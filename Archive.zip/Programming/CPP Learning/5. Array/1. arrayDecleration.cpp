#include<iostream>
using namespace std;
int main(){
    // Decleration 
    int myNum[5];

    // Initialization
    
}