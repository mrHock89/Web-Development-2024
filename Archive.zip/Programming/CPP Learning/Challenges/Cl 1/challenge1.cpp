// Challenge 1
#include<iostream>
using namespace std;
int main(){
    string typesOfTea = "Green Tea";
    float teaPrice = 129.50; // PerKg
    char teaRating = 'A';


    // Displaying tea
    cout << "Tea information Display: \n";
    cout << "Types of tea: \""<< typesOfTea << "\"\n";
    cout << "Tea Price per Kilogram " << teaPrice << " INR\n"; 
    cout << "Tea Rating: " << teaRating << "\n";
    return 0;
}