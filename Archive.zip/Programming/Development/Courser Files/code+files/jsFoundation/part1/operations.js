let score = 102;
let bonus = 25;

let totalScore = score + bonus;

let addition = 4 + 5;
let subtract = 9 - 3;
let mult = 3 * 5;
let divi = 8 / 2;
let reminder = 9 % 2;
let expo = 2 ** 3;

let myscore = 110;
myscore++;

let credits = 56;
credits--;

// Comparion operation

let num1 = 3;
let num2 = 3;
let num3 = 6;

console.log(num1 == num2); //true
console.log(num1 != num3); // true
console.log(num1 > num3); // true
console.log(num1 < num3); // true
