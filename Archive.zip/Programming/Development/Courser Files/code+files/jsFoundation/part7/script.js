console.log("Hello from script");
